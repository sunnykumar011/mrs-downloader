# MRS Downloader

Starter project: static frontend for GitHub Pages + a Node.js metadata API.

## Important limitations
- GitHub Pages hosts only the frontend. The Node.js API must be deployed separately.
- This project checks metadata for permitted **direct media URLs**. It does not extract streams from YouTube, Instagram, Facebook, or bypass their restrictions.
- Some hosts block `HEAD` requests or cross-origin browser downloads. In that case, metadata/download may not work from that host.
- A browser cannot reliably force another server to download a file; the source may open or stream it instead.
- Do not use this service to download content you do not own or have permission to save.

## 1. Deploy the backend (Node.js)
1. Create a GitHub repository and upload `server.js` and `package.json` to its root.
2. On a Node.js hosting provider, create a new web service from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variable `ALLOWED_ORIGINS` with your exact GitHub Pages origin, for example `https://YOUR-USERNAME.github.io`. For a project page, the origin is still `https://YOUR-USERNAME.github.io` (not the repository path).
6. Copy the deployed backend URL and test `https://YOUR-BACKEND-URL/api/health`.

Free-tier availability, sleep behavior, and limits vary by provider and may change.

## 2. Connect the frontend
Open `public/script.js` and add this line near the top, replacing the URL with your deployed backend URL:
```js
window.MRS_API_BASE = "https://YOUR-BACKEND-URL";
```
Commit the change.

## 3. Publish frontend on GitHub Pages
1. Put the contents of `public/` in the root of a separate GitHub repository (or configure Pages to publish the `/public` folder if your setup supports it).
2. In repository Settings → Pages, choose deploy from branch and select `main` and `/ (root)` if the files are in the root.
3. Wait for the published URL, then open it on mobile and desktop.

## 4. Local test
Install Node.js 20 or newer.
```bash
npm install
npm start
```
Open `http://localhost:3000/api/health`. For the frontend, serve the `public` folder with any static file server (or use VS Code Live Server). Set `window.MRS_API_BASE` to `http://localhost:3000` while testing locally.

## Safety note
This starter validates public HTTP(S) URLs and blocks common private/local host patterns, but it is not a hardened public download proxy. Do not add a proxy endpoint that fetches arbitrary URLs or forwards entire files without stronger SSRF defenses, rate limits, authentication, and abuse controls.
