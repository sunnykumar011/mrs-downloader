const express = require("express");
const cors = require("cors");
const dns = require("node:dns/promises");
const net = require("node:net");

const app = express();
const PORT = process.env.PORT || 3000;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "*").split(",").map(x => x.trim());
app.use(cors({ origin: (origin, cb) => {
  if (!origin || ALLOWED_ORIGINS.includes("*") || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
  return cb(new Error("Origin not allowed"));
}}));
app.use(express.json({ limit: "20kb" }));
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "MRS Downloader API" }));

function isPrivateIPv4(ip) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 10 || p[0] === 127 || p[0] === 0 ||
    (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) || p[0] >= 224;
}
async function validatePublicUrl(raw) {
  let url;
  try { url = new URL(raw); } catch { throw new Error("Invalid URL"); }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only HTTP/HTTPS URLs are supported");
  if (url.username || url.password) throw new Error("URLs containing credentials are not supported");
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) throw new Error("Private/local hosts are not supported");
  if (net.isIP(host) === 4 && isPrivateIPv4(host)) throw new Error("Private IP addresses are not supported");
  if (net.isIP(host) === 6 && (host === "::1" || host.startsWith("fc") || host.startsWith("fd") || host.startsWith("fe80"))) throw new Error("Private IP addresses are not supported");
  if (!net.isIP(host)) {
    const addresses = await dns.lookup(host, { all: true });
    if (!addresses.length || addresses.some(a => a.family === 4 && isPrivateIPv4(a.address) || a.family === 6 && (a.address === "::1" || /^(fc|fd|fe80)/i.test(a.address)))) {
      throw new Error("Host resolves to a private address");
    }
  }
  return url;
}
app.get("/api/metadata", async (req, res) => {
  try {
    const url = await validatePublicUrl(req.query.url);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      // No redirects: prevents silently following a URL to an internal host.
      const response = await fetch(url, { method: "HEAD", redirect: "manual", signal: controller.signal, headers: { "User-Agent": "MRS-Downloader/1.0" } });
      if (response.status >= 300 && response.status < 400) return res.status(400).json({ error: "This source redirects. Use its final direct media URL if you have permission." });
      if (!response.ok) return res.status(400).json({ error: `Source returned HTTP ${response.status}` });
      const contentType = response.headers.get("content-type")?.split(";")[0] || "application/octet-stream";
      const length = Number(response.headers.get("content-length"));
      const fileName = decodeURIComponent(url.pathname.split("/").pop() || "media-file").slice(0, 180);
      res.json({ contentType, size: Number.isFinite(length) && length >= 0 ? length : null, fileName });
    } finally { clearTimeout(timer); }
  } catch (err) {
    res.status(400).json({ error: err.name === "AbortError" ? "Source timed out" : err.message || "Could not inspect source" });
  }
});
app.listen(PORT, () => console.log(`MRS Downloader API listening on ${PORT}`));
